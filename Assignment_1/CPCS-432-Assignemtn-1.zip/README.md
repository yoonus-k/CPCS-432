# CPCS-432
 Assignment 1 NLP

## sources

[AMR-KELEG](https://github.com/AMR-KELEG/arabic-word-inflection/blob/master/inflect.py)

[sarf](https://github.com/alsaydi/sarf/tree/master)
